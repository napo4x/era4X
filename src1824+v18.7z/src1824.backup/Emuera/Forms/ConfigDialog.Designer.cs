﻿namespace MinorShift.Emuera.Forms
{
	partial class ConfigDialog
	{
		/// <summary>
		/// 必要なデザイナ変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナで生成されたコード

		/// <summary>
		/// デザイナ サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディタで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConfigDialog));
			this.buttonSave = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.buttonReboot = new System.Windows.Forms.Button();
			this.tabControl = new System.Windows.Forms.TabControl();
			this.tabEnvironment = new System.Windows.Forms.TabPage();
			this.comboBox6 = new System.Windows.Forms.ComboBox();
			this.checkBox24 = new System.Windows.Forms.CheckBox();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.label23 = new System.Windows.Forms.Label();
			this.button4 = new System.Windows.Forms.Button();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label22 = new System.Windows.Forms.Label();
			this.label20 = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.numericUpDown11 = new System.Windows.Forms.NumericUpDown();
			this.checkBox18 = new System.Windows.Forms.CheckBox();
			this.numericUpDown10 = new System.Windows.Forms.NumericUpDown();
			this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
			this.checkBox7 = new System.Windows.Forms.CheckBox();
			this.checkBox6 = new System.Windows.Forms.CheckBox();
			this.checkBox5 = new System.Windows.Forms.CheckBox();
			this.checkBox4 = new System.Windows.Forms.CheckBox();
			this.checkBox3 = new System.Windows.Forms.CheckBox();
			this.tabPageView = new System.Windows.Forms.TabPage();
			this.checkBox14 = new System.Windows.Forms.CheckBox();
			this.label18 = new System.Windows.Forms.Label();
			this.comboBoxTextDrawingMode = new System.Windows.Forms.ComboBox();
			this.label1 = new System.Windows.Forms.Label();
			this.numericUpDown9 = new System.Windows.Forms.NumericUpDown();
			this.label5 = new System.Windows.Forms.Label();
			this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
			this.label9 = new System.Windows.Forms.Label();
			this.numericUpDown7 = new System.Windows.Forms.NumericUpDown();
			this.tabPageWindow = new System.Windows.Forms.TabPage();
			this.checkBox21 = new System.Windows.Forms.CheckBox();
			this.ScrollRange = new System.Windows.Forms.Label();
			this.numericUpDown8 = new System.Windows.Forms.NumericUpDown();
			this.checkBox17 = new System.Windows.Forms.CheckBox();
			this.button3 = new System.Windows.Forms.Button();
			this.label10 = new System.Windows.Forms.Label();
			this.label19 = new System.Windows.Forms.Label();
			this.numericUpDownPosY = new System.Windows.Forms.NumericUpDown();
			this.numericUpDownPosX = new System.Windows.Forms.NumericUpDown();
			this.button1 = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
			this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
			this.checkBox8 = new System.Windows.Forms.CheckBox();
			this.tabPageFont = new System.Windows.Forms.TabPage();
			this.button2 = new System.Windows.Forms.Button();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.numericUpDown6 = new System.Windows.Forms.NumericUpDown();
			this.numericUpDown5 = new System.Windows.Forms.NumericUpDown();
			this.label4 = new System.Windows.Forms.Label();
			this.comboBox2 = new System.Windows.Forms.ComboBox();
			this.colorBoxBacklog = new MinorShift.Emuera.Forms.ColorBox();
			this.colorBoxSelecting = new MinorShift.Emuera.Forms.ColorBox();
			this.colorBoxFG = new MinorShift.Emuera.Forms.ColorBox();
			this.colorBoxBG = new MinorShift.Emuera.Forms.ColorBox();
			this.tabPageSystem = new System.Windows.Forms.TabPage();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.label11 = new System.Windows.Forms.Label();
			this.checkBoxSystemFullSpace = new System.Windows.Forms.CheckBox();
			this.checkBox22 = new System.Windows.Forms.CheckBox();
			this.label21 = new System.Windows.Forms.Label();
			this.checkBox20 = new System.Windows.Forms.CheckBox();
			this.checkBox19 = new System.Windows.Forms.CheckBox();
			this.checkBox16 = new System.Windows.Forms.CheckBox();
			this.checkBox15 = new System.Windows.Forms.CheckBox();
			this.checkBox1 = new System.Windows.Forms.CheckBox();
			this.checkBox10 = new System.Windows.Forms.CheckBox();
			this.checkBox2 = new System.Windows.Forms.CheckBox();
			this.tabPageSystem2 = new System.Windows.Forms.TabPage();
			this.checkBox29 = new System.Windows.Forms.CheckBox();
			this.checkBox26 = new System.Windows.Forms.CheckBox();
			this.checkBox27 = new System.Windows.Forms.CheckBox();
			this.checkBoxSystemTripleSymbol = new System.Windows.Forms.CheckBox();
			this.label24 = new System.Windows.Forms.Label();
			this.tabPageCompati = new System.Windows.Forms.TabPage();
			this.checkBox9 = new System.Windows.Forms.CheckBox();
			this.checkBoxCompatiSP = new System.Windows.Forms.CheckBox();
			this.checkBox28 = new System.Windows.Forms.CheckBox();
			this.checkBox25 = new System.Windows.Forms.CheckBox();
			this.checkBox12 = new System.Windows.Forms.CheckBox();
			this.checkBoxFuncNoIgnoreCase = new System.Windows.Forms.CheckBox();
			this.button8 = new System.Windows.Forms.Button();
			this.button7 = new System.Windows.Forms.Button();
			this.checkBoxCompatiLinefeedAs1739 = new System.Windows.Forms.CheckBox();
			this.checkBoxCompatiRAND = new System.Windows.Forms.CheckBox();
			this.label30 = new System.Windows.Forms.Label();
			this.checkBoxCompatiCALLNAME = new System.Windows.Forms.CheckBox();
			this.checkBoxCompatiErrorLine = new System.Windows.Forms.CheckBox();
			this.tabPageDebug = new System.Windows.Forms.TabPage();
			this.button6 = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			this.checkBox23 = new System.Windows.Forms.CheckBox();
			this.label15 = new System.Windows.Forms.Label();
			this.comboBox5 = new System.Windows.Forms.ComboBox();
			this.label14 = new System.Windows.Forms.Label();
			this.comboBox4 = new System.Windows.Forms.ComboBox();
			this.label13 = new System.Windows.Forms.Label();
			this.comboBox3 = new System.Windows.Forms.ComboBox();
			this.label12 = new System.Windows.Forms.Label();
			this.comboBoxReduceArgumentOnLoad = new System.Windows.Forms.ComboBox();
			this.checkBox11 = new System.Windows.Forms.CheckBox();
			this.checkBox13 = new System.Windows.Forms.CheckBox();
			this.label16 = new System.Windows.Forms.Label();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
			this.tabControl.SuspendLayout();
			this.tabEnvironment.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown11)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
			this.tabPageView.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).BeginInit();
			this.tabPageWindow.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDownPosY)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDownPosX)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
			this.tabPageFont.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).BeginInit();
			this.tabPageSystem.SuspendLayout();
			this.tabPageSystem2.SuspendLayout();
			this.tabPageCompati.SuspendLayout();
			this.tabPageDebug.SuspendLayout();
			this.SuspendLayout();
			// 
			// buttonSave
			// 
			resources.ApplyResources(this.buttonSave, "buttonSave");
			this.buttonSave.Name = "buttonSave";
			this.buttonSave.UseVisualStyleBackColor = true;
			this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
			// 
			// buttonCancel
			// 
			resources.ApplyResources(this.buttonCancel, "buttonCancel");
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.UseVisualStyleBackColor = true;
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// buttonReboot
			// 
			resources.ApplyResources(this.buttonReboot, "buttonReboot");
			this.buttonReboot.Name = "buttonReboot";
			this.buttonReboot.UseVisualStyleBackColor = true;
			this.buttonReboot.Click += new System.EventHandler(this.buttonReboot_Click);
			// 
			// tabControl
			// 
			this.tabControl.Controls.Add(this.tabEnvironment);
			this.tabControl.Controls.Add(this.tabPageView);
			this.tabControl.Controls.Add(this.tabPageWindow);
			this.tabControl.Controls.Add(this.tabPageFont);
			this.tabControl.Controls.Add(this.tabPageSystem);
			this.tabControl.Controls.Add(this.tabPageSystem2);
			this.tabControl.Controls.Add(this.tabPageCompati);
			this.tabControl.Controls.Add(this.tabPageDebug);
			resources.ApplyResources(this.tabControl, "tabControl");
			this.tabControl.Multiline = true;
			this.tabControl.Name = "tabControl";
			this.tabControl.SelectedIndex = 0;
			// 
			// tabEnvironment
			// 
			this.tabEnvironment.Controls.Add(this.comboBox6);
			this.tabEnvironment.Controls.Add(this.checkBox24);
			this.tabEnvironment.Controls.Add(this.textBox2);
			this.tabEnvironment.Controls.Add(this.label23);
			this.tabEnvironment.Controls.Add(this.button4);
			this.tabEnvironment.Controls.Add(this.textBox1);
			this.tabEnvironment.Controls.Add(this.label22);
			this.tabEnvironment.Controls.Add(this.label20);
			this.tabEnvironment.Controls.Add(this.label17);
			this.tabEnvironment.Controls.Add(this.label6);
			this.tabEnvironment.Controls.Add(this.numericUpDown11);
			this.tabEnvironment.Controls.Add(this.checkBox18);
			this.tabEnvironment.Controls.Add(this.numericUpDown10);
			this.tabEnvironment.Controls.Add(this.numericUpDown4);
			this.tabEnvironment.Controls.Add(this.checkBox7);
			this.tabEnvironment.Controls.Add(this.checkBox6);
			this.tabEnvironment.Controls.Add(this.checkBox5);
			this.tabEnvironment.Controls.Add(this.checkBox4);
			this.tabEnvironment.Controls.Add(this.checkBox3);
			resources.ApplyResources(this.tabEnvironment, "tabEnvironment");
			this.tabEnvironment.Name = "tabEnvironment";
			this.tabEnvironment.UseVisualStyleBackColor = true;
			// 
			// comboBox6
			// 
			this.comboBox6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox6.FormattingEnabled = true;
			this.comboBox6.Items.AddRange(new object[] {
            resources.GetString("comboBox6.Items"),
            resources.GetString("comboBox6.Items1"),
            resources.GetString("comboBox6.Items2"),
            resources.GetString("comboBox6.Items3")});
			resources.ApplyResources(this.comboBox6, "comboBox6");
			this.comboBox6.Name = "comboBox6";
			this.comboBox6.SelectedIndexChanged += new System.EventHandler(this.comboBox6_SelectedIndexChanged);
			// 
			// checkBox24
			// 
			resources.ApplyResources(this.checkBox24, "checkBox24");
			this.checkBox24.Name = "checkBox24";
			this.checkBox24.UseVisualStyleBackColor = true;
			// 
			// textBox2
			// 
			resources.ApplyResources(this.textBox2, "textBox2");
			this.textBox2.Name = "textBox2";
			// 
			// label23
			// 
			resources.ApplyResources(this.label23, "label23");
			this.label23.Name = "label23";
			// 
			// button4
			// 
			resources.ApplyResources(this.button4, "button4");
			this.button4.Name = "button4";
			this.button4.UseVisualStyleBackColor = true;
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// textBox1
			// 
			resources.ApplyResources(this.textBox1, "textBox1");
			this.textBox1.Name = "textBox1";
			// 
			// label22
			// 
			resources.ApplyResources(this.label22, "label22");
			this.label22.Name = "label22";
			// 
			// label20
			// 
			resources.ApplyResources(this.label20, "label20");
			this.label20.Name = "label20";
			// 
			// label17
			// 
			resources.ApplyResources(this.label17, "label17");
			this.label17.Name = "label17";
			// 
			// label6
			// 
			resources.ApplyResources(this.label6, "label6");
			this.label6.Name = "label6";
			// 
			// numericUpDown11
			// 
			resources.ApplyResources(this.numericUpDown11, "numericUpDown11");
			this.numericUpDown11.Name = "numericUpDown11";
			// 
			// checkBox18
			// 
			resources.ApplyResources(this.checkBox18, "checkBox18");
			this.checkBox18.Name = "checkBox18";
			this.checkBox18.UseVisualStyleBackColor = true;
			// 
			// numericUpDown10
			// 
			resources.ApplyResources(this.numericUpDown10, "numericUpDown10");
			this.numericUpDown10.Name = "numericUpDown10";
			// 
			// numericUpDown4
			// 
			resources.ApplyResources(this.numericUpDown4, "numericUpDown4");
			this.numericUpDown4.Name = "numericUpDown4";
			// 
			// checkBox7
			// 
			resources.ApplyResources(this.checkBox7, "checkBox7");
			this.checkBox7.Name = "checkBox7";
			this.checkBox7.UseVisualStyleBackColor = true;
			// 
			// checkBox6
			// 
			resources.ApplyResources(this.checkBox6, "checkBox6");
			this.checkBox6.Name = "checkBox6";
			this.checkBox6.UseVisualStyleBackColor = true;
			// 
			// checkBox5
			// 
			resources.ApplyResources(this.checkBox5, "checkBox5");
			this.checkBox5.Name = "checkBox5";
			this.checkBox5.UseVisualStyleBackColor = true;
			// 
			// checkBox4
			// 
			resources.ApplyResources(this.checkBox4, "checkBox4");
			this.checkBox4.Name = "checkBox4";
			this.checkBox4.UseVisualStyleBackColor = true;
			// 
			// checkBox3
			// 
			resources.ApplyResources(this.checkBox3, "checkBox3");
			this.checkBox3.Name = "checkBox3";
			this.checkBox3.UseVisualStyleBackColor = true;
			// 
			// tabPageView
			// 
			this.tabPageView.Controls.Add(this.checkBox14);
			this.tabPageView.Controls.Add(this.label18);
			this.tabPageView.Controls.Add(this.comboBoxTextDrawingMode);
			this.tabPageView.Controls.Add(this.label1);
			this.tabPageView.Controls.Add(this.numericUpDown9);
			this.tabPageView.Controls.Add(this.label5);
			this.tabPageView.Controls.Add(this.numericUpDown1);
			this.tabPageView.Controls.Add(this.label9);
			this.tabPageView.Controls.Add(this.numericUpDown7);
			resources.ApplyResources(this.tabPageView, "tabPageView");
			this.tabPageView.Name = "tabPageView";
			this.tabPageView.UseVisualStyleBackColor = true;
			// 
			// checkBox14
			// 
			resources.ApplyResources(this.checkBox14, "checkBox14");
			this.checkBox14.Name = "checkBox14";
			this.checkBox14.UseVisualStyleBackColor = true;
			// 
			// label18
			// 
			resources.ApplyResources(this.label18, "label18");
			this.label18.Name = "label18";
			// 
			// comboBoxTextDrawingMode
			// 
			this.comboBoxTextDrawingMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxTextDrawingMode.FormattingEnabled = true;
			this.comboBoxTextDrawingMode.Items.AddRange(new object[] {
            resources.GetString("comboBoxTextDrawingMode.Items"),
            resources.GetString("comboBoxTextDrawingMode.Items1"),
            resources.GetString("comboBoxTextDrawingMode.Items2")});
			resources.ApplyResources(this.comboBoxTextDrawingMode, "comboBoxTextDrawingMode");
			this.comboBoxTextDrawingMode.Name = "comboBoxTextDrawingMode";
			// 
			// label1
			// 
			resources.ApplyResources(this.label1, "label1");
			this.label1.Name = "label1";
			// 
			// numericUpDown9
			// 
			resources.ApplyResources(this.numericUpDown9, "numericUpDown9");
			this.numericUpDown9.Name = "numericUpDown9";
			// 
			// label5
			// 
			resources.ApplyResources(this.label5, "label5");
			this.label5.Name = "label5";
			// 
			// numericUpDown1
			// 
			resources.ApplyResources(this.numericUpDown1, "numericUpDown1");
			this.numericUpDown1.Name = "numericUpDown1";
			// 
			// label9
			// 
			resources.ApplyResources(this.label9, "label9");
			this.label9.Name = "label9";
			// 
			// numericUpDown7
			// 
			resources.ApplyResources(this.numericUpDown7, "numericUpDown7");
			this.numericUpDown7.Name = "numericUpDown7";
			// 
			// tabPageWindow
			// 
			this.tabPageWindow.Controls.Add(this.checkBox21);
			this.tabPageWindow.Controls.Add(this.ScrollRange);
			this.tabPageWindow.Controls.Add(this.numericUpDown8);
			this.tabPageWindow.Controls.Add(this.checkBox17);
			this.tabPageWindow.Controls.Add(this.button3);
			this.tabPageWindow.Controls.Add(this.label10);
			this.tabPageWindow.Controls.Add(this.label19);
			this.tabPageWindow.Controls.Add(this.numericUpDownPosY);
			this.tabPageWindow.Controls.Add(this.numericUpDownPosX);
			this.tabPageWindow.Controls.Add(this.button1);
			this.tabPageWindow.Controls.Add(this.label3);
			this.tabPageWindow.Controls.Add(this.label2);
			this.tabPageWindow.Controls.Add(this.numericUpDown3);
			this.tabPageWindow.Controls.Add(this.numericUpDown2);
			this.tabPageWindow.Controls.Add(this.checkBox8);
			resources.ApplyResources(this.tabPageWindow, "tabPageWindow");
			this.tabPageWindow.Name = "tabPageWindow";
			this.tabPageWindow.UseVisualStyleBackColor = true;
			// 
			// checkBox21
			// 
			resources.ApplyResources(this.checkBox21, "checkBox21");
			this.checkBox21.Name = "checkBox21";
			this.checkBox21.UseVisualStyleBackColor = true;
			// 
			// ScrollRange
			// 
			resources.ApplyResources(this.ScrollRange, "ScrollRange");
			this.ScrollRange.Name = "ScrollRange";
			// 
			// numericUpDown8
			// 
			resources.ApplyResources(this.numericUpDown8, "numericUpDown8");
			this.numericUpDown8.Name = "numericUpDown8";
			// 
			// checkBox17
			// 
			resources.ApplyResources(this.checkBox17, "checkBox17");
			this.checkBox17.Name = "checkBox17";
			this.checkBox17.UseVisualStyleBackColor = true;
			// 
			// button3
			// 
			resources.ApplyResources(this.button3, "button3");
			this.button3.Name = "button3";
			this.button3.UseVisualStyleBackColor = true;
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// label10
			// 
			resources.ApplyResources(this.label10, "label10");
			this.label10.Name = "label10";
			// 
			// label19
			// 
			resources.ApplyResources(this.label19, "label19");
			this.label19.Name = "label19";
			// 
			// numericUpDownPosY
			// 
			resources.ApplyResources(this.numericUpDownPosY, "numericUpDownPosY");
			this.numericUpDownPosY.Name = "numericUpDownPosY";
			// 
			// numericUpDownPosX
			// 
			resources.ApplyResources(this.numericUpDownPosX, "numericUpDownPosX");
			this.numericUpDownPosX.Name = "numericUpDownPosX";
			// 
			// button1
			// 
			resources.ApplyResources(this.button1, "button1");
			this.button1.Name = "button1";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// label3
			// 
			resources.ApplyResources(this.label3, "label3");
			this.label3.Name = "label3";
			// 
			// label2
			// 
			resources.ApplyResources(this.label2, "label2");
			this.label2.Name = "label2";
			// 
			// numericUpDown3
			// 
			resources.ApplyResources(this.numericUpDown3, "numericUpDown3");
			this.numericUpDown3.Name = "numericUpDown3";
			// 
			// numericUpDown2
			// 
			resources.ApplyResources(this.numericUpDown2, "numericUpDown2");
			this.numericUpDown2.Name = "numericUpDown2";
			// 
			// checkBox8
			// 
			resources.ApplyResources(this.checkBox8, "checkBox8");
			this.checkBox8.Name = "checkBox8";
			this.checkBox8.UseVisualStyleBackColor = true;
			// 
			// tabPageFont
			// 
			this.tabPageFont.Controls.Add(this.button2);
			this.tabPageFont.Controls.Add(this.label7);
			this.tabPageFont.Controls.Add(this.label8);
			this.tabPageFont.Controls.Add(this.numericUpDown6);
			this.tabPageFont.Controls.Add(this.numericUpDown5);
			this.tabPageFont.Controls.Add(this.label4);
			this.tabPageFont.Controls.Add(this.comboBox2);
			this.tabPageFont.Controls.Add(this.colorBoxBacklog);
			this.tabPageFont.Controls.Add(this.colorBoxSelecting);
			this.tabPageFont.Controls.Add(this.colorBoxFG);
			this.tabPageFont.Controls.Add(this.colorBoxBG);
			resources.ApplyResources(this.tabPageFont, "tabPageFont");
			this.tabPageFont.Name = "tabPageFont";
			this.tabPageFont.UseVisualStyleBackColor = true;
			// 
			// button2
			// 
			resources.ApplyResources(this.button2, "button2");
			this.button2.Name = "button2";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// label7
			// 
			resources.ApplyResources(this.label7, "label7");
			this.label7.Name = "label7";
			// 
			// label8
			// 
			resources.ApplyResources(this.label8, "label8");
			this.label8.Name = "label8";
			// 
			// numericUpDown6
			// 
			resources.ApplyResources(this.numericUpDown6, "numericUpDown6");
			this.numericUpDown6.Name = "numericUpDown6";
			// 
			// numericUpDown5
			// 
			resources.ApplyResources(this.numericUpDown5, "numericUpDown5");
			this.numericUpDown5.Name = "numericUpDown5";
			// 
			// label4
			// 
			resources.ApplyResources(this.label4, "label4");
			this.label4.Name = "label4";
			// 
			// comboBox2
			// 
			resources.ApplyResources(this.comboBox2, "comboBox2");
			this.comboBox2.Name = "comboBox2";
			// 
			// colorBoxBacklog
			// 
			this.colorBoxBacklog.ButtonText = "履歴文字色";
			resources.ApplyResources(this.colorBoxBacklog, "colorBoxBacklog");
			this.colorBoxBacklog.Name = "colorBoxBacklog";
			this.colorBoxBacklog.SelectingColor = System.Drawing.Color.Transparent;
			// 
			// colorBoxSelecting
			// 
			this.colorBoxSelecting.ButtonText = "選択中文字色";
			resources.ApplyResources(this.colorBoxSelecting, "colorBoxSelecting");
			this.colorBoxSelecting.Name = "colorBoxSelecting";
			this.colorBoxSelecting.SelectingColor = System.Drawing.Color.Transparent;
			// 
			// colorBoxFG
			// 
			this.colorBoxFG.ButtonText = "文字色";
			resources.ApplyResources(this.colorBoxFG, "colorBoxFG");
			this.colorBoxFG.Name = "colorBoxFG";
			this.colorBoxFG.SelectingColor = System.Drawing.Color.Transparent;
			// 
			// colorBoxBG
			// 
			this.colorBoxBG.ButtonText = "背景色";
			resources.ApplyResources(this.colorBoxBG, "colorBoxBG");
			this.colorBoxBG.Name = "colorBoxBG";
			this.colorBoxBG.SelectingColor = System.Drawing.Color.Transparent;
			// 
			// tabPageSystem
			// 
			this.tabPageSystem.Controls.Add(this.comboBox1);
			this.tabPageSystem.Controls.Add(this.label11);
			this.tabPageSystem.Controls.Add(this.checkBoxSystemFullSpace);
			this.tabPageSystem.Controls.Add(this.checkBox22);
			this.tabPageSystem.Controls.Add(this.label21);
			this.tabPageSystem.Controls.Add(this.checkBox20);
			this.tabPageSystem.Controls.Add(this.checkBox19);
			this.tabPageSystem.Controls.Add(this.checkBox16);
			this.tabPageSystem.Controls.Add(this.checkBox15);
			this.tabPageSystem.Controls.Add(this.checkBox1);
			this.tabPageSystem.Controls.Add(this.checkBox10);
			this.tabPageSystem.Controls.Add(this.checkBox2);
			resources.ApplyResources(this.tabPageSystem, "tabPageSystem");
			this.tabPageSystem.Name = "tabPageSystem";
			this.tabPageSystem.UseVisualStyleBackColor = true;
			// 
			// comboBox1
			// 
			this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Items.AddRange(new object[] {
            resources.GetString("comboBox1.Items"),
            resources.GetString("comboBox1.Items1"),
            resources.GetString("comboBox1.Items2"),
            resources.GetString("comboBox1.Items3")});
			resources.ApplyResources(this.comboBox1, "comboBox1");
			this.comboBox1.Name = "comboBox1";
			// 
			// label11
			// 
			resources.ApplyResources(this.label11, "label11");
			this.label11.Name = "label11";
			// 
			// checkBoxSystemFullSpace
			// 
			resources.ApplyResources(this.checkBoxSystemFullSpace, "checkBoxSystemFullSpace");
			this.checkBoxSystemFullSpace.Name = "checkBoxSystemFullSpace";
			this.checkBoxSystemFullSpace.UseVisualStyleBackColor = true;
			// 
			// checkBox22
			// 
			resources.ApplyResources(this.checkBox22, "checkBox22");
			this.checkBox22.Name = "checkBox22";
			this.checkBox22.UseVisualStyleBackColor = true;
			// 
			// label21
			// 
			resources.ApplyResources(this.label21, "label21");
			this.label21.Name = "label21";
			// 
			// checkBox20
			// 
			resources.ApplyResources(this.checkBox20, "checkBox20");
			this.checkBox20.Name = "checkBox20";
			this.checkBox20.UseVisualStyleBackColor = true;
			// 
			// checkBox19
			// 
			resources.ApplyResources(this.checkBox19, "checkBox19");
			this.checkBox19.Name = "checkBox19";
			this.checkBox19.UseVisualStyleBackColor = true;
			// 
			// checkBox16
			// 
			resources.ApplyResources(this.checkBox16, "checkBox16");
			this.checkBox16.Name = "checkBox16";
			this.checkBox16.UseVisualStyleBackColor = true;
			// 
			// checkBox15
			// 
			resources.ApplyResources(this.checkBox15, "checkBox15");
			this.checkBox15.Name = "checkBox15";
			this.checkBox15.UseVisualStyleBackColor = true;
			// 
			// checkBox1
			// 
			resources.ApplyResources(this.checkBox1, "checkBox1");
			this.checkBox1.Name = "checkBox1";
			this.checkBox1.UseVisualStyleBackColor = true;
			// 
			// checkBox10
			// 
			resources.ApplyResources(this.checkBox10, "checkBox10");
			this.checkBox10.Name = "checkBox10";
			this.checkBox10.UseVisualStyleBackColor = true;
			// 
			// checkBox2
			// 
			resources.ApplyResources(this.checkBox2, "checkBox2");
			this.checkBox2.Name = "checkBox2";
			this.checkBox2.UseVisualStyleBackColor = true;
			// 
			// tabPageSystem2
			// 
			this.tabPageSystem2.Controls.Add(this.checkBox29);
			this.tabPageSystem2.Controls.Add(this.checkBox26);
			this.tabPageSystem2.Controls.Add(this.checkBox27);
			this.tabPageSystem2.Controls.Add(this.checkBoxSystemTripleSymbol);
			this.tabPageSystem2.Controls.Add(this.label24);
			resources.ApplyResources(this.tabPageSystem2, "tabPageSystem2");
			this.tabPageSystem2.Name = "tabPageSystem2";
			this.tabPageSystem2.UseVisualStyleBackColor = true;
			// 
			// checkBox29
			// 
			resources.ApplyResources(this.checkBox29, "checkBox29");
			this.checkBox29.Name = "checkBox29";
			this.checkBox29.UseVisualStyleBackColor = true;
			// 
			// checkBox26
			// 
			resources.ApplyResources(this.checkBox26, "checkBox26");
			this.checkBox26.Name = "checkBox26";
			this.checkBox26.UseVisualStyleBackColor = true;
			// 
			// checkBox27
			// 
			resources.ApplyResources(this.checkBox27, "checkBox27");
			this.checkBox27.Name = "checkBox27";
			this.checkBox27.UseVisualStyleBackColor = true;
			// 
			// checkBoxSystemTripleSymbol
			// 
			resources.ApplyResources(this.checkBoxSystemTripleSymbol, "checkBoxSystemTripleSymbol");
			this.checkBoxSystemTripleSymbol.Name = "checkBoxSystemTripleSymbol";
			this.checkBoxSystemTripleSymbol.UseVisualStyleBackColor = true;
			// 
			// label24
			// 
			resources.ApplyResources(this.label24, "label24");
			this.label24.Name = "label24";
			// 
			// tabPageCompati
			// 
			this.tabPageCompati.Controls.Add(this.checkBox9);
			this.tabPageCompati.Controls.Add(this.checkBoxCompatiSP);
			this.tabPageCompati.Controls.Add(this.checkBox28);
			this.tabPageCompati.Controls.Add(this.checkBox25);
			this.tabPageCompati.Controls.Add(this.checkBox12);
			this.tabPageCompati.Controls.Add(this.checkBoxFuncNoIgnoreCase);
			this.tabPageCompati.Controls.Add(this.button8);
			this.tabPageCompati.Controls.Add(this.button7);
			this.tabPageCompati.Controls.Add(this.checkBoxCompatiLinefeedAs1739);
			this.tabPageCompati.Controls.Add(this.checkBoxCompatiRAND);
			this.tabPageCompati.Controls.Add(this.label30);
			this.tabPageCompati.Controls.Add(this.checkBoxCompatiCALLNAME);
			this.tabPageCompati.Controls.Add(this.checkBoxCompatiErrorLine);
			resources.ApplyResources(this.tabPageCompati, "tabPageCompati");
			this.tabPageCompati.Name = "tabPageCompati";
			this.tabPageCompati.UseVisualStyleBackColor = true;
			// 
			// checkBox9
			// 
			resources.ApplyResources(this.checkBox9, "checkBox9");
			this.checkBox9.Name = "checkBox9";
			this.checkBox9.UseVisualStyleBackColor = true;
			// 
			// checkBoxCompatiSP
			// 
			resources.ApplyResources(this.checkBoxCompatiSP, "checkBoxCompatiSP");
			this.checkBoxCompatiSP.Name = "checkBoxCompatiSP";
			this.toolTip1.SetToolTip(this.checkBoxCompatiSP, resources.GetString("checkBoxCompatiSP.ToolTip"));
			this.checkBoxCompatiSP.UseVisualStyleBackColor = true;
			// 
			// checkBox28
			// 
			resources.ApplyResources(this.checkBox28, "checkBox28");
			this.checkBox28.Name = "checkBox28";
			this.toolTip1.SetToolTip(this.checkBox28, resources.GetString("checkBox28.ToolTip"));
			this.checkBox28.UseVisualStyleBackColor = true;
			// 
			// checkBox25
			// 
			resources.ApplyResources(this.checkBox25, "checkBox25");
			this.checkBox25.Name = "checkBox25";
			this.toolTip1.SetToolTip(this.checkBox25, resources.GetString("checkBox25.ToolTip"));
			this.checkBox25.UseVisualStyleBackColor = true;
			// 
			// checkBox12
			// 
			resources.ApplyResources(this.checkBox12, "checkBox12");
			this.checkBox12.Name = "checkBox12";
			this.toolTip1.SetToolTip(this.checkBox12, resources.GetString("checkBox12.ToolTip"));
			this.checkBox12.UseVisualStyleBackColor = true;
			// 
			// checkBoxFuncNoIgnoreCase
			// 
			resources.ApplyResources(this.checkBoxFuncNoIgnoreCase, "checkBoxFuncNoIgnoreCase");
			this.checkBoxFuncNoIgnoreCase.Name = "checkBoxFuncNoIgnoreCase";
			this.toolTip1.SetToolTip(this.checkBoxFuncNoIgnoreCase, resources.GetString("checkBoxFuncNoIgnoreCase.ToolTip"));
			this.checkBoxFuncNoIgnoreCase.UseVisualStyleBackColor = true;
			// 
			// button8
			// 
			resources.ApplyResources(this.button8, "button8");
			this.button8.Name = "button8";
			this.button8.UseVisualStyleBackColor = true;
			this.button8.Click += new System.EventHandler(this.button8_Click);
			// 
			// button7
			// 
			resources.ApplyResources(this.button7, "button7");
			this.button7.Name = "button7";
			this.button7.UseVisualStyleBackColor = true;
			this.button7.Click += new System.EventHandler(this.button7_Click);
			// 
			// checkBoxCompatiLinefeedAs1739
			// 
			resources.ApplyResources(this.checkBoxCompatiLinefeedAs1739, "checkBoxCompatiLinefeedAs1739");
			this.checkBoxCompatiLinefeedAs1739.Name = "checkBoxCompatiLinefeedAs1739";
			this.toolTip1.SetToolTip(this.checkBoxCompatiLinefeedAs1739, resources.GetString("checkBoxCompatiLinefeedAs1739.ToolTip"));
			this.checkBoxCompatiLinefeedAs1739.UseVisualStyleBackColor = true;
			// 
			// checkBoxCompatiRAND
			// 
			resources.ApplyResources(this.checkBoxCompatiRAND, "checkBoxCompatiRAND");
			this.checkBoxCompatiRAND.Name = "checkBoxCompatiRAND";
			this.toolTip1.SetToolTip(this.checkBoxCompatiRAND, resources.GetString("checkBoxCompatiRAND.ToolTip"));
			this.checkBoxCompatiRAND.UseVisualStyleBackColor = true;
			// 
			// label30
			// 
			resources.ApplyResources(this.label30, "label30");
			this.label30.Name = "label30";
			// 
			// checkBoxCompatiCALLNAME
			// 
			resources.ApplyResources(this.checkBoxCompatiCALLNAME, "checkBoxCompatiCALLNAME");
			this.checkBoxCompatiCALLNAME.Name = "checkBoxCompatiCALLNAME";
			this.toolTip1.SetToolTip(this.checkBoxCompatiCALLNAME, resources.GetString("checkBoxCompatiCALLNAME.ToolTip"));
			this.checkBoxCompatiCALLNAME.UseVisualStyleBackColor = true;
			// 
			// checkBoxCompatiErrorLine
			// 
			resources.ApplyResources(this.checkBoxCompatiErrorLine, "checkBoxCompatiErrorLine");
			this.checkBoxCompatiErrorLine.Name = "checkBoxCompatiErrorLine";
			this.toolTip1.SetToolTip(this.checkBoxCompatiErrorLine, resources.GetString("checkBoxCompatiErrorLine.ToolTip"));
			this.checkBoxCompatiErrorLine.UseVisualStyleBackColor = true;
			// 
			// tabPageDebug
			// 
			this.tabPageDebug.Controls.Add(this.button6);
			this.tabPageDebug.Controls.Add(this.button5);
			this.tabPageDebug.Controls.Add(this.checkBox23);
			this.tabPageDebug.Controls.Add(this.label15);
			this.tabPageDebug.Controls.Add(this.comboBox5);
			this.tabPageDebug.Controls.Add(this.label14);
			this.tabPageDebug.Controls.Add(this.comboBox4);
			this.tabPageDebug.Controls.Add(this.label13);
			this.tabPageDebug.Controls.Add(this.comboBox3);
			this.tabPageDebug.Controls.Add(this.label12);
			this.tabPageDebug.Controls.Add(this.comboBoxReduceArgumentOnLoad);
			this.tabPageDebug.Controls.Add(this.checkBox11);
			this.tabPageDebug.Controls.Add(this.checkBox13);
			resources.ApplyResources(this.tabPageDebug, "tabPageDebug");
			this.tabPageDebug.Name = "tabPageDebug";
			this.tabPageDebug.UseVisualStyleBackColor = true;
			// 
			// button6
			// 
			resources.ApplyResources(this.button6, "button6");
			this.button6.Name = "button6";
			this.button6.UseVisualStyleBackColor = true;
			this.button6.Click += new System.EventHandler(this.button6_Click);
			// 
			// button5
			// 
			resources.ApplyResources(this.button5, "button5");
			this.button5.Name = "button5";
			this.button5.UseVisualStyleBackColor = true;
			this.button5.Click += new System.EventHandler(this.button5_Click);
			// 
			// checkBox23
			// 
			resources.ApplyResources(this.checkBox23, "checkBox23");
			this.checkBox23.Name = "checkBox23";
			this.checkBox23.UseVisualStyleBackColor = true;
			// 
			// label15
			// 
			resources.ApplyResources(this.label15, "label15");
			this.label15.Name = "label15";
			// 
			// comboBox5
			// 
			this.comboBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox5.FormattingEnabled = true;
			this.comboBox5.Items.AddRange(new object[] {
            resources.GetString("comboBox5.Items"),
            resources.GetString("comboBox5.Items1"),
            resources.GetString("comboBox5.Items2"),
            resources.GetString("comboBox5.Items3")});
			resources.ApplyResources(this.comboBox5, "comboBox5");
			this.comboBox5.Name = "comboBox5";
			// 
			// label14
			// 
			resources.ApplyResources(this.label14, "label14");
			this.label14.Name = "label14";
			// 
			// comboBox4
			// 
			this.comboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox4.FormattingEnabled = true;
			this.comboBox4.Items.AddRange(new object[] {
            resources.GetString("comboBox4.Items"),
            resources.GetString("comboBox4.Items1"),
            resources.GetString("comboBox4.Items2"),
            resources.GetString("comboBox4.Items3")});
			resources.ApplyResources(this.comboBox4, "comboBox4");
			this.comboBox4.Name = "comboBox4";
			// 
			// label13
			// 
			resources.ApplyResources(this.label13, "label13");
			this.label13.Name = "label13";
			// 
			// comboBox3
			// 
			this.comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox3.FormattingEnabled = true;
			this.comboBox3.Items.AddRange(new object[] {
            resources.GetString("comboBox3.Items"),
            resources.GetString("comboBox3.Items1"),
            resources.GetString("comboBox3.Items2"),
            resources.GetString("comboBox3.Items3")});
			resources.ApplyResources(this.comboBox3, "comboBox3");
			this.comboBox3.Name = "comboBox3";
			// 
			// label12
			// 
			resources.ApplyResources(this.label12, "label12");
			this.label12.Name = "label12";
			// 
			// comboBoxReduceArgumentOnLoad
			// 
			this.comboBoxReduceArgumentOnLoad.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxReduceArgumentOnLoad.FormattingEnabled = true;
			this.comboBoxReduceArgumentOnLoad.Items.AddRange(new object[] {
            resources.GetString("comboBoxReduceArgumentOnLoad.Items"),
            resources.GetString("comboBoxReduceArgumentOnLoad.Items1"),
            resources.GetString("comboBoxReduceArgumentOnLoad.Items2")});
			resources.ApplyResources(this.comboBoxReduceArgumentOnLoad, "comboBoxReduceArgumentOnLoad");
			this.comboBoxReduceArgumentOnLoad.Name = "comboBoxReduceArgumentOnLoad";
			this.comboBoxReduceArgumentOnLoad.SelectedIndexChanged += new System.EventHandler(this.comboBoxReduceArgumentOnLoad_SelectedIndexChanged);
			// 
			// checkBox11
			// 
			resources.ApplyResources(this.checkBox11, "checkBox11");
			this.checkBox11.Name = "checkBox11";
			this.checkBox11.UseVisualStyleBackColor = true;
			// 
			// checkBox13
			// 
			resources.ApplyResources(this.checkBox13, "checkBox13");
			this.checkBox13.Name = "checkBox13";
			this.checkBox13.UseVisualStyleBackColor = true;
			// 
			// label16
			// 
			resources.ApplyResources(this.label16, "label16");
			this.label16.Name = "label16";
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.FileName = "openFileDialog1";
			// 
			// ConfigDialog
			// 
			resources.ApplyResources(this, "$this");
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.label16);
			this.Controls.Add(this.tabControl);
			this.Controls.Add(this.buttonReboot);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.buttonSave);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ConfigDialog";
			this.ShowIcon = false;
			this.ShowInTaskbar = false;
			this.tabControl.ResumeLayout(false);
			this.tabEnvironment.ResumeLayout(false);
			this.tabEnvironment.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown11)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
			this.tabPageView.ResumeLayout(false);
			this.tabPageView.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).EndInit();
			this.tabPageWindow.ResumeLayout(false);
			this.tabPageWindow.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDownPosY)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDownPosX)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
			this.tabPageFont.ResumeLayout(false);
			this.tabPageFont.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).EndInit();
			this.tabPageSystem.ResumeLayout(false);
			this.tabPageSystem.PerformLayout();
			this.tabPageSystem2.ResumeLayout(false);
			this.tabPageSystem2.PerformLayout();
			this.tabPageCompati.ResumeLayout(false);
			this.tabPageCompati.PerformLayout();
			this.tabPageDebug.ResumeLayout(false);
			this.tabPageDebug.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button buttonSave;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.Button buttonReboot;
        private System.Windows.Forms.TabControl tabControl;
		private System.Windows.Forms.TabPage tabPageFont;
		private System.Windows.Forms.TabPage tabPageDebug;
		private MinorShift.Emuera.Forms.ColorBox colorBoxFG;
		private MinorShift.Emuera.Forms.ColorBox colorBoxBG;
		private MinorShift.Emuera.Forms.ColorBox colorBoxBacklog;
        private MinorShift.Emuera.Forms.ColorBox colorBoxSelecting;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.NumericUpDown numericUpDown6;
		private System.Windows.Forms.NumericUpDown numericUpDown5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ComboBox comboBox2;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.ComboBox comboBox4;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.ComboBox comboBox3;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.ComboBox comboBoxReduceArgumentOnLoad;
		private System.Windows.Forms.CheckBox checkBox11;
		private System.Windows.Forms.CheckBox checkBox13;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.ComboBox comboBox5;
		private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TabPage tabPageView;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.NumericUpDown numericUpDown7;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.NumericUpDown numericUpDown9;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.NumericUpDown numericUpDown1;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.ComboBox comboBoxTextDrawingMode;
        private System.Windows.Forms.CheckBox checkBox14;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.TabPage tabPageWindow;
		private System.Windows.Forms.CheckBox checkBox17;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.NumericUpDown numericUpDownPosY;
		private System.Windows.Forms.NumericUpDown numericUpDownPosX;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.NumericUpDown numericUpDown3;
		private System.Windows.Forms.NumericUpDown numericUpDown2;
		private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.Label ScrollRange;
		private System.Windows.Forms.NumericUpDown numericUpDown8;
		private System.Windows.Forms.TabPage tabEnvironment;
		private System.Windows.Forms.NumericUpDown numericUpDown11;
		private System.Windows.Forms.CheckBox checkBox18;
		private System.Windows.Forms.NumericUpDown numericUpDown10;
		private System.Windows.Forms.NumericUpDown numericUpDown4;
		private System.Windows.Forms.CheckBox checkBox7;
		private System.Windows.Forms.CheckBox checkBox6;
		private System.Windows.Forms.CheckBox checkBox5;
		private System.Windows.Forms.CheckBox checkBox4;
		private System.Windows.Forms.CheckBox checkBox3;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox checkBox21;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.TabPage tabPageCompati;
		private System.Windows.Forms.Label label30;
		private System.Windows.Forms.CheckBox checkBoxCompatiCALLNAME;
		private System.Windows.Forms.CheckBox checkBoxCompatiErrorLine;
		private System.Windows.Forms.CheckBox checkBox24;
		private System.Windows.Forms.CheckBox checkBoxCompatiLinefeedAs1739;
		private System.Windows.Forms.CheckBox checkBoxCompatiRAND;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.ToolTip toolTip1;
		private System.Windows.Forms.CheckBox checkBox23;
        private System.Windows.Forms.CheckBox checkBoxFuncNoIgnoreCase;
        private System.Windows.Forms.TabPage tabPageSystem;
        private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox checkBoxSystemFullSpace;
        private System.Windows.Forms.CheckBox checkBox22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.CheckBox checkBox20;
        private System.Windows.Forms.CheckBox checkBox19;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox2;
		private System.Windows.Forms.CheckBox checkBox25;
		private System.Windows.Forms.CheckBox checkBox12;
		private System.Windows.Forms.CheckBox checkBox28;
		private System.Windows.Forms.TabPage tabPageSystem2;
		private System.Windows.Forms.CheckBox checkBoxSystemTripleSymbol;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.CheckBox checkBox26;
		private System.Windows.Forms.CheckBox checkBox27;
		private System.Windows.Forms.CheckBox checkBoxCompatiSP;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.CheckBox checkBox9;
		private System.Windows.Forms.CheckBox checkBox29;
	}
}